"use strict";
// Uso de Let y Const
var nombre = "Nestor Kauil";
var edad = 25;
var PERSONAJE = {
    nombre: nombre,
    edad: edad
};
console.log(PERSONAJE);
