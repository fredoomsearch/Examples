// Uso de Let y Const
let nombre:string = "Nestor Kauil";
let edad:number   = 25;
const PERSONAJE: { nombre:string, edad:number } = {
    nombre: nombre,
    edad: edad
}
console.log(PERSONAJE);